<?php if (isset($component)) { $__componentOriginal1f9e5f64f242295036c059d9dc1c375c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c = $attributes; } ?>
<?php $component = App\View\Components\Layout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-16 text-center">
        <h1 class="text-4xl font-bold text-indigo-700">
            Welcome to the Game Review Board
        </h1>

        <h2 class="mx-auto mt-6 max-w-xl text-lg font-semibold text-gray-700">
            Our Mission
        </h2>
        <p class="mx-auto mt-4 max-w-xl text-lg text-gray-600">
            Our mission is to provide a platform for gamers to share their honest opinions and reviews about their favorite games. We believe that every gamer has a voice, and we want to create a community where those voices can be heard.
        </p>

        <h2 class="mx-auto mt-6 max-w-xl text-lg font-semibold text-gray-700">
            Our Vision
        </h2>
        <p class="mx-auto mt-4 max-w-xl text-lg text-gray-600">
            Our vision is to become the go-to destination for gamers who want to discover new games, read honest reviews, and connect with other members of the gaming community.
        </p>

        <a href="<?php echo e(url('/reviews')); ?>" class="mt-6 inline-block rounded-lg bg-indigo-600 px-6 py-3 text-white shadow-md transition duration-300 hover:bg-indigo-700">
            Browse Games
        </a>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $attributes = $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $component = $__componentOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?><?php /**PATH C:\Users\deguzman_a\Documents\LARAVEL\my-app\resources\views/home.blade.php ENDPATH**/ ?>