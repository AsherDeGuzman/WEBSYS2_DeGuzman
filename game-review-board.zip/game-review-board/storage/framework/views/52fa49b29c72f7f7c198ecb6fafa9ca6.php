<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Game Review Board</title>
    <?php if(file_exists(public_path('build/manifest.json'))): ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php endif; ?>
</head>
<body class="min-h-screen bg-gray-100 text-slate-800">
    <header class="bg-indigo-700 text-white shadow-md">
        <nav class="mx-auto flex max-w-6xl items-center justify-between px-4 py-4 sm:px-6 lg:px-8">
            <a href="<?php echo e(url('/')); ?>" class="text-xl font-bold">Game Review Board</a>
            <div class="flex items-center gap-4 text-sm font-medium">
                <a href="<?php echo e(url('/')); ?>" class="hover:text-indigo-200 hover:underline">Home</a>
                <a href="<?php echo e(url('/about')); ?>" class="hover:text-indigo-200 hover:underline">About</a>
                <a href="<?php echo e(url('/reviews')); ?>" class="hover:text-indigo-200 hover:underline">Reviews</a>
            </div>
        </nav>
    </header>

    <main class="mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:px-8">
        <?php echo e($slot); ?>

    </main>
</body>
</html><?php /**PATH C:\Users\deguzman_a\Documents\LARAVEL\my-app\resources\views/components/layout.blade.php ENDPATH**/ ?>