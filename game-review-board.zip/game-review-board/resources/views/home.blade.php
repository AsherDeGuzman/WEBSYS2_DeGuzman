<x-layout>
    <div class="py-16 text-center">
        <h1 class="text-4xl font-bold text-indigo-700">
            Welcome to the Game Review Board
        </h1>

        <h2 class="mx-auto mt-6 max-w-xl text-lg font-semibold text-gray-700">
            Our Mission
        </h2>
        <p class="mx-auto mt-4 max-w-xl text-lg text-gray-600">
            Our mission is to provide a platform for gamers to share their honest opinions and reviews about their favorite games. We believe that every gamer has a voice, and we want to create a community where those voices can be heard.
        </p>

        <h2 class="mx-auto mt-6 max-w-xl text-lg font-semibold text-gray-700">
            Our Vision
        </h2>
        <p class="mx-auto mt-4 max-w-xl text-lg text-gray-600">
            Our vision is to become the go-to destination for gamers who want to discover new games, read honest reviews, and connect with other members of the gaming community.
        </p>

        <a href="{{ url('/reviews') }}" class="mt-6 inline-block rounded-lg bg-indigo-600 px-6 py-3 text-white shadow-md transition duration-300 hover:bg-indigo-700">
            Browse Games
        </a>
    </div>
</x-layout>