<x-layout>
    <div class="py-16 text-center">
        <h1 class="text-4xl font-bold text-indigo-700">
            About the Game Review Board
        </h1>
        <p class="mx-auto mt-4 max-w-xl text-lg text-gray-600">
            The Game Review Board is a community-driven platform where gamers can share their honest opinions and reviews about their favorite games. Our mission is to provide a space for gamers to connect, share experiences, and help others make informed decisions about the games they play.
        </p>
        <a href="{{ url('/reviews') }}" class="mt-6 inline-block rounded-lg bg-indigo-600 px-6 py-3 text-white shadow-md transition duration-300 hover:bg-indigo-700">
            Browse Games
        </a>
    </div>
</x-layout>