<x-layout>
    <div class="space-y-8 py-8">
        <div class="text-center">
            <h1 class="text-4xl font-bold text-indigo-700">Game Reviews</h1>
        </div>

        @foreach ($gameReviews as $gameReview)
            <article class="rounded-xl border border-gray-200 bg-white p-6 shadow-sm">
                
                <h2 class="mt-2 text-2xl font-bold text-gray-900">{{ $gameReview['title'] }}</h2>
                <p class="text-sm font-semibold uppercase tracking-wide text-indigo-600">Author: {{ $gameReview['author'] }}</p>
                <p class="mt-4 text-base leading-relaxed text-gray-700">{{ $gameReview['review'] }}</p>
            </article>
        @endforeach
    </div>
</x-layout>
