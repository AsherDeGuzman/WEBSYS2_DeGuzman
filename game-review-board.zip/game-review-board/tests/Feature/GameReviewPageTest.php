<?php

test('the game reviews page loads and renders review data', function () {
    $response = $this->get('/reviews');

    $response->assertOk();
    $response->assertSee('The Legend of Zelda: Breath of the Wild');
    $response->assertSee('Jeremy Pogi');
});
