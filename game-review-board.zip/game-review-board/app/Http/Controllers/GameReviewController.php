<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\View\View;

class GameReviewController extends Controller
{
    public function index(): View
    {
        $gameReviews = [
            [
                'author' => 'Jeremy Pogi',
                'title' => 'The Legend of Zelda: Breath of the Wild',
                'review' => 'An amazing open-world adventure that redefines the genre.',
            ],
            [
                'author' => 'Jane Doe',
                'title' => 'Super Mario Odyssey',
                'review' => 'A delightful platformer with creative level design and charming characters.',
            ],
            [
                'author' => 'John Smith',
                'title' => 'The Witcher 3: Wild Hunt',
                'review' => 'A masterpiece of storytelling and world-building, with deep RPG mechanics.',
            ],
        ];



        return view('game-reviews.index', ['gameReviews' => $gameReviews]);
    }
}
